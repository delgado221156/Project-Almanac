//
//  DetailTid.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import SwiftUI

struct DetailTid: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DetailTid_Previews: PreviewProvider {
    static var previews: some View {
        DetailTid()
    }
}
