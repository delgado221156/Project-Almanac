//
//  TidBits.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import SwiftUI

struct TidBitsScreen: View {
    
    var body: some View {
 
        
        NavigationView{
            
            List{
                //Loopping through each city in my CityData File
                ForEach(TidBitData){ TidBit in // city is the new name for each value in my list
                    
                    //CLASS EXERCISE: pt 2 - attemt stylling the layout for each ciry from the class slides
                    NavigationLink(destination: DetailTid(TidBits: TidBit)){// Passing city as a param to the screen
                        HStack{
                            Image(systemName: TidBit.icon)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .padding(10)
                                .foregroundColor(.white)
                                .background(.blue)
                                .cornerRadius(10)
                            
                            VStack(alignment: .leading){
                                Text(TidBit.name)
                                    .font(.title2)
                                Text(TidBit.info)
                            }
                            
                            Spacer()
                            
                            Text("\(TidBit.category)")
                                .font(.title)
                                .bold()
                        }//- END of HStack
                    }//- END NavigationLink
                    
                }//- END of ForEach loop
            }//- END of List
            .listStyle(.inset)// Change style of List
            
            
                .navigationTitle("All Cities")//Inside navigationView
                .navigationBarTitleDisplayMode(.large)
        }//- END of Navigation
    }
}

struct CityListScreen_Previews: PreviewProvider {
    static var previews: some View {
        CityListScreen()
    }
}
