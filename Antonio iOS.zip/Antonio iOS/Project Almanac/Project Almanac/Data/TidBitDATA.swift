//
//  TidBitDATA.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import Foundation
let TidBitData: [TidBits] = [
    TidBits(
        name: "testart",
        info: "flkrtkrbr rtghrt r rkjkrr thg rtkhjrkth kr h g ggkg rj i krjkjgkkg ktkrt ",
        category: "Art",
        icon: "theatermask.and.paintbrush.fill"
      
       
    ),
    TidBits(
        name: "testart",
        info: "flkrtkrbrgrtn h   yytytty tytyjt ty tyjtyjtyjt ytjjtj",
        category: "Camping",
        icon: "tent.2.fill"

       
    )]
   
