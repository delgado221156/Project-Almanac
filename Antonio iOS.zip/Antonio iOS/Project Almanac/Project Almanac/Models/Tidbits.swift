//
//  Tidbits.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import Foundation
struct TidBits: Identifiable{
    var id = UUID() //unique id for each city that is autogenorated
    var name: String
    var info: String
    var category: String
    var icon: String
    
    
    //Dummy City from my Schema(all my previews)
   /* let dummyTidbit: TidBit = TidBit(
        name: "Camping Tarps",
        info: "Use a tarp on the ground to safeguard you from dust getting into the tent.",
        category: "Camping",
        icon: "tent.fill",
        
    )*/
}
