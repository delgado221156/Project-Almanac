//
//  ContentView.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import SwiftUI

let name = "Project Almanac"

// body = SWIFTUI CODE
var body: some View {
    
    //  STACKS = divs that can place views to be Vertical(V), Horizontal(H) or On Top off eachother(Z)
    
    ZStack {// Stack the Views On Top Of Eachother
        Color(".black")
            .ignoresSafeArea(.all)
        VStack (alignment: .center){// Stack the Views Vertically
            Image(systemName:"book.closed.fill")
                .resizable()
                .renderingMode(.original)
                .aspectRatio(contentMode: .fit)
                .foregroundColor(.white)
                .frame(width:250, height: 250)
            
            HStack(alignment: .bottom, spacing:20){
                Text("Hello")
                Text(name).bold()
            }
        }
    }
    
}
