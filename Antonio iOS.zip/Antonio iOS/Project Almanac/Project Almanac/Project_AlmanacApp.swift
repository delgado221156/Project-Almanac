//
//  Project_AlmanacApp.swift
//  Project Almanac
//
//  Created by student on 2023/10/16.
//

import SwiftUI

@main
struct Project_AlmanacApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
