//
//  CityData.swift
//  weather-app-test
//
//  Created by student on 2023/10/15.
//


//right click data -> New File -> swift File -> CityData
import Foundation
//Adding my weather/city data

let CityData: [City] = [
    City(
        name: "Southdown",
        area: "Gauteng",
        maxTemp: 18,
        minTemp: 6,
        icon: "cloud",
        windSpeed: 3,
        humidity: 45,
        weekdayWeather: [
            Weather(day: "Wed", icon: "cloud", temp: 12),
            Weather(day: "Thu", icon: "cloud.rain", temp: 5),
            Weather(day: "Fri", icon: "cloud.sun", temp: 22)
        ]
    ),
    City(
        name: "Cape Town",
        area: "Western Cape",
        maxTemp: 26,
        minTemp: 14,
        icon: "cloud.sun",
        windSpeed: 40,
        humidity: 20,
        weekdayWeather: [
            Weather(day: "Wed", icon: "cloud.sun", temp: 26),
            Weather(day: "Thu", icon: "cloud.rain", temp: 12),
            Weather(day: "Fri", icon: "cloud.sun", temp: 20)
        ]
    ),
    City(
        name: "Stellenbosch",
        area: "Western Cape",
        maxTemp: 19,
        minTemp: 9,
        icon: "cloud",
        windSpeed: 14,
        humidity: 10,
        weekdayWeather: [
            Weather(day: "Wed", icon: "cloud", temp: 19),
            Weather(day: "Thu", icon: "cloud.rain", temp: 12),
            Weather(day: "Fri", icon: "cloud.sun", temp: 29)
        ]
    ),
    City(
        name: "Johannesburg",
        area: "Gauteng",
        maxTemp: 20,
        minTemp: 3,
        icon: "cloud.rain",
        windSpeed: 1,
        humidity: 52,
        weekdayWeather: [
            Weather(day: "Wed", icon: "cloud.rain", temp: 20),
            Weather(day: "Thu", icon: "cloud.rain", temp: 5),
            Weather(day: "Fri", icon: "cloud.sun", temp: 21)
        ]
    )
]

//CLASS EXERCISE: Add 3 more cities in your CiryData for (Stellenbosch, Johannesburg, Cape Town)
