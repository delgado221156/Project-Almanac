//
//  weather_app_testApp.swift
//  weather-app-test
//
//  Created by student on 2023/10/11.
//

import SwiftUI
//Entry point of your APp // App.js file in react
@main
struct weather_app_testApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
//            WeatherScreen()
            CityListScreen()
            //TODO: Display all the cities nd add navigation
        }
    }
}
