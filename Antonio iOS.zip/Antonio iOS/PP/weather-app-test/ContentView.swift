//
//  ContentView.swift
//  weather-app-test
//
//  Created by student on 2023/10/11.
//

// sIMPORTS - all of our packages we will be using...
import SwiftUI


// View - Think of this struct  as a component/ sub view
struct ContentView: View {
    
    // Here we define any of our  variables and function.
    let name = "Antonio"
    
    // body = SWIFTUI CODE
    var body: some View {
        
//  STACKS = divs that can place views to be Vertical(V), Horizontal(H) or On Top off eachother(Z)
        
        ZStack {// Stack the Views On Top Of Eachother
            Color("AccentColor")
                .ignoresSafeArea(.all)
            VStack (alignment: .center){// Stack the Views Vertically
                Image(systemName: "cloud")
                    .resizable()
                    .renderingMode(.original)
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(.white)
                    .frame(width:250, height: 250)
                
                HStack(alignment: .bottom, spacing:20){
                    Text("Hello")
                    Text(name).bold()
                }
            }
        }
        
        
//        Text(name) //every View is called like it is a Function

//        Example of a control Button(//Functionality as an action){//How          the Button should look
//        Text(name)
//            .bold() //modifiers =  function to modify the style of Views
//                    //VIEW().MODIFIER().MODIFIER()
//            .foregroundColor(Color("ErrorColor"))
//            .padding()
//
//        Button(action: {
//            //Functionality of Button
//            print("Hello")
//        }) {
//
//            //Appearance of Button
//
//
//            Image(systemName: "cloud.bolt.rain")
//                .resizable()
//                .aspectRatio(contentMode: .fit)
//                .foregroundColor(.white)
//                .frame(width:200, height: 200)
//
//            Spacer()
            
//
//            Text("Text").italic()
            
//        }.background(.gray)
//            .padding()
        
    }
}

// PREVIEW STRUNCTURE := This is what makes us see the preview on the right sides
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
