//
//  WeekDayForecastView.swift
//  weather-app-test
//
//  Created by student on 2023/10/12.
//

import SwiftUI

struct WeekDayForecastView: View {
    //VAR
    //var parameter: String (NO EQUAL SIGN = PARAMETER)
    //If we do not add a sign, we need to pass the variable everytime we create this week
    var weather: Weather //This is a parameter
    var isToday: Bool = false
    
    var body: some View {
        VStack(spacing: 10){
            Text(weather.day)
                .textCase(.uppercase)
                .foregroundColor(.white)
            
            Image(systemName: weather.icon)
                .imageScale(.large)
                .foregroundColor(.white)
            
            Text("\(weather.temp)º")
                .bold()
                .font(.title3)
                .foregroundColor(.white)
            
        }
            .padding(10)
            .background(isToday ? .blue : .clear)//if this week
            .cornerRadius(10)
    }
}

struct WeekDayForecastView_Previews: PreviewProvider {
    static var previews: some View {
        //Becauese my weather variable is my view is a parameter. I need to pass the value that it is equal to as a parameter when I call it.
        WeekDayForecastView(weather: dummyWeather)
            .previewLayout(.sizeThatFits)
            .padding()
            .previewDisplayName("Individual Weekly Forecast")
    }
}
