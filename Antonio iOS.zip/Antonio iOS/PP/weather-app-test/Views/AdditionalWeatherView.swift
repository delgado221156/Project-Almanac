//
//  AdditionalWeatherView.swift
//  weather-app-test
//
//  Created by student on 2023/10/15.
//

import SwiftUI

struct AdditionalWeatherView: View {
    //right click on Views -> New File -> SwiftUIView
    
    var icon = "wind"
    var title = "Wind Speed"
    var value = "33 km/h"
    
    var body: some View {
        HStack{
            Image(systemName: icon)
            Text("\(title)")
            Spacer()
            Text(value)
                .bold()
        }
        .padding()
        .background(.white)
        .foregroundColor(.blue)
        .cornerRadius(20)
    }
}

struct AdditionalWeatherView_Previews: PreviewProvider {
    static var previews: some View {
        AdditionalWeatherView()
    }
}
