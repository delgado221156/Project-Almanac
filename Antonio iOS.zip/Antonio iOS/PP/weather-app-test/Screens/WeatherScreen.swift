//
//  WeatherScreen.swift
//  weather-app-test
//
//  Created by student on 2023/10/12.
//

//Imports
import SwiftUI


//Content to Display
struct WeatherScreen: View {
    
    //Values - Param
    var city: City = dummyCity
    
    //VIEW
    var body: some View {
        ZStack{ //ZStack to place content ontop of gradiant
            
            LinearGradient(colors: [.blue ,.white], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea(.all)
            
            VStack (spacing: 20) {
                //-Top Main Info
                Text("\(city.name), \(city.area)")
                    .font(.title3)
                    .foregroundColor(.white)
                    .padding(.vertical)
                
                Image(systemName: city.icon)
                    .renderingMode(.original)
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.white)
                    .frame(width: 140, height: 140)
                
//                  Styling of different colour for icons
                
//                  .symbolRenderingMode(.palette)
//                  .foregroundStyle(.white, .yellow)
//                  .font(.system(size: 140))
                
                Text("\(city.maxTemp)º")
                    .font(.system(size: 64))
                    .bold()
                    .foregroundColor(.white)
                
                Text("Wed, 3 October 2023")
                    .font(.headline)
                    .foregroundColor(.white)
                
                Spacer()
                
                //-Weekly Forecast
                ScrollView(.horizontal){
                    HStack{
                        ForEach(city.weekdayWeather){day in
                            WeekDayForecastView(weather: day, isToday: false)//TODO: Check index of ForEach  index loop
                        }
                    }//END - HStack
                }//END - Weekly Forecast
                
                Spacer()
                
                //minTemp, Wind, humidity
                TabView {
                    AdditionalWeatherView(icon: "thermometer.snowflake", title: "Min Temprature", value: "\(city.minTemp)º")
                        .padding()
                    AdditionalWeatherView(icon: "wind", title: "Wind Speed", value: "\(city.windSpeed) km/h")
                        .padding()
                    AdditionalWeatherView(icon: "humidity", title: "Humidity", value: "\(city.humidity)%")
                        .padding()
                }
                .padding(.vertical)
                .tabViewStyle(.page)// This style makes the content a carousel
                
                
            }.padding(20)//END - Outer VStack
            
        }//END - ZStack
        
    }
}


//Preview Display
struct WeatherScreen_Previews: PreviewProvider {
    static var previews: some View {
        WeatherScreen()
    }
}
