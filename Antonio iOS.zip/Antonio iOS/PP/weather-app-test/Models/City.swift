//
//  City.swift
//  weather-app-test
//
//  Created by student on 2023/10/12.
//

import Foundation

//This model is a blueprint/Schema of my city data

struct City: Identifiable{
    var id = UUID() //unique id for each city that is autogenorated
    var name: String
    var area: String
    var maxTemp: Int
    var minTemp: Int
    var icon: String
    var windSpeed: Int
    var humidity: Int
    //Weekday forecast
    var weekdayWeather: [Weather] //variableequal to an array of all my weather data
}

//Dummy City from my Schema(all my previews)
let dummyCity: City = City(
    name: "Southdown",
    area: "Centurion",
    maxTemp: 24,
    minTemp: 9,
    icon: "cloud.sun",
    windSpeed: 12,
    humidity: 33,
    weekdayWeather: [dummyWeather, dummyWeather]
)
