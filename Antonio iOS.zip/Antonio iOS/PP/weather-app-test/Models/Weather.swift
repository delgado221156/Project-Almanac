//
//  Weather.swift
//  weather-app-test
//
//  Created by student on 2023/10/12.
//

import Foundation

struct Weather: Identifiable{
    var id = UUID() //unique id for each city that is autogenorated
    var day: String
    var icon: String
    var temp: Int
}

let dummyWeather: Weather = Weather(
    day: "Wed",
    icon: "sun.min",
    temp: 30
)
