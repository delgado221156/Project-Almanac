//
//  Card.swift
//  Weather App
//
//  Created by student on 2023/10/18.
//

//import SwiftUI
//
//struct CardView: View {
//
//    var card: Card //parameter
//    var body: some View {
//        VStack(spacing: 20){
//            Text(card.title)
//                .textCase(.uppercase)
//                .foregroundColor(.white)
//                .bold()
//
//
//            Image(systemName: card.icon)
//                .imageScale(.large)
//                .foregroundColor(.white)
//
//            Text(card.text)
//
//                .font(.title3)
//                .foregroundColor(.white)
//        }
//        .padding(10)
//        .background(.blue )
//        .cornerRadius(10)
//    }
//}
//
//struct Card_Previews: PreviewProvider {
//    static var previews: some View {
//        CardView(card: dummyCard)
//            .previewLayout(.sizeThatFits)
//            .padding()
//            .previewDisplayName("Individual weekly forecast")
//    }
//}
import SwiftUI
 struct OnboardingCardView: View {
     var title: String
     var description: String
     var icon: String
     
     var body: some View {
         
         VStack (alignment:  .center, spacing: 20){
             Text (title)
                 .font(.system(size: 52, weight: .heavy)) 
                 .multilineTextAlignment (.center)
                 .bold()
             Image (systemName: icon)
                 .resizable()
                 .scaledToFit()
                 .symbolRenderingMode(.palette)
                 .foregroundStyle(.white, .yellow)
                 .frame(width: 140, height: 140)
                 .padding()
             Text (description)
                 .multilineTextAlignment(.center)
                 .font(.title)
                 .bold()
         }
         .padding(40)
         .frame(maxWidth: .infinity)
         .background(.blue)
         .cornerRadius(20)
         .foregroundColor(.white)
         .shadow(color: .black.opacity(0.3), radius: 20, x: 2, y: 10)
         
     }
     
 }
 
 struct OnboardingCardView_Previews: PreviewProvider{
 static var previews: some View{
 OnboardingCardView(title: "Welcome", description: "welcome to dskjsdsbdsdbjkbdjb", icon: "cloud.rain.fill")
 }
 }
