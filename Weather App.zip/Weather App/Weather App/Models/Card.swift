//
//  Card.swift
//  Weather App
//
//  Created by student on 2023/10/18.
//

import Foundation


//Class Exercise: - create a new struct called Weather and include the following:
//day of the week, icon, temperature

struct Card: Identifiable {
    var id = UUID()
    var title: String
    var icon: String
    var text: String
}

let dummyCard: Card = Card(title: "welcome bro!", icon: "sun.min", text: "gdgd")
