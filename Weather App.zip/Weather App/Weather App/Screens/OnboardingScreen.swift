//
//  OnboardingScreen.swift
//  Weather App
//
//  Created by student on 2023/10/18.
//

import SwiftUI

struct OnboardingScreen: View {
    @AppStorage("isOnboarded") var isOnboarded = false
    var body: some View {
        VStack{
            TabView{
                //CardView( title: "Welcome!", icon: "humidity", text: "wassup bro!")
//                CardView(card: dummyCard)
//                    .previewLayout(.sizeThatFits)
//                    .padding()
//                    .previewDisplayName("Individual weekly forecast")
                OnboardingCardView(title: "welcome", description: "hdhd", icon: "cloud.sun.fill")
                    .padding()
                OnboardingCardView(title: "welcome", description: "hdhd", icon: "search")
                    .padding()
                OnboardingCardView(title: "welcome", description: "hdhd", icon: "cloud.sun.fill")
                    .padding()
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            Button(action:{
                //update app storage
            }){
                HStack{
                    Text("Continue to app")
                        .padding()
                    Spacer()
                    Image(systemName: "arrow.right.circle.fill")
                        .padding()
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
    }
}

struct OnboardingScreen_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingScreen()
    }
}
