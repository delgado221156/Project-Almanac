//
//  SettingsScreen.swift
//  Weather App
//
//  Created by student on 2023/10/18.
//

import SwiftUI

struct SettingsScreen: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) var colorScheme //access the device settings
    @State var username = ""
    @AppStorage("displayMode") var displayMode = "primary"
    var body: some View {
        VStack(spacing:20){
            HStack{
                Text("Settings")
                    .font(.title)
                Spacer()
                
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .onTapGesture {
                        dismiss()
                    }
            }
            
            //about us
            GroupBox{
                HStack{
                    Text("Developed by")
                    Spacer()
                    //create a link
                   // Link("iOS Developer", destination: URL( string: "https://github.com/" )!)
                        .bold()
                    Image(systemName: "link")
                        
                }
                Divider()
                HStack{
                    Text("Version")
                    Spacer()
                    Text("1.0.0")
                        .bold()
                }
            }
            Divider().padding()
            GroupBox{
                DisclosureGroup("About this app"){
                    Text("This is an app to display weather as an examplke for my ios subject").padding().bold(false)
                }.foregroundColor(colorScheme == .light ? .black : .white).bold()//? refers to if statement and : means else statement
            }
            if(colorScheme == .light){
                Text("Colour scheme is set to \(colorScheme == .dark ? "Dark":"Light")")
            }
           Text("Your Username")
            TextField("Your Username", text: $username)
                .padding()
                .background(.blue)
                .cornerRadius(20)
            
            Text("Display Mode")
            Picker("Mode", selection: $displayMode){
                Text("Primary").tag("primary")
                Text("Secondary").tag("secondary")
            }
            //.pickerStyle(.wheel)
            .pickerStyle(.segmented)
            
            Spacer()
        }
        .padding()
    }
}

struct SettingsScreen_Previews: PreviewProvider {
    static var previews: some View {
        SettingsScreen()
        //add styling
    }
}
