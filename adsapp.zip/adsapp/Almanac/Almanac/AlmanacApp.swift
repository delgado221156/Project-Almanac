//
//  AlmanacApp.swift
//  Almanac
//
//  Created by student on 2023/10/18.
//

import SwiftUI

@main
struct AlmanacApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
