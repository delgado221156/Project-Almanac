//
//  SettingsScreen.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import SwiftUI
struct SettingsScreen: View {
    var body: some View {
        ZStack{
            
            LinearGradient(colors: [.purple, .black], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea(.all)
            
            VStack{
                Text("Settings")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
            }
            Spacer()
            }
        }
       
}

struct SettingsScreen_Previews: PreviewProvider {
    static var previews: some View {
        SettingsScreen()
        //add styling
    }
}
