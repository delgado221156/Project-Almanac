//
//  TidBitListScreen.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import SwiftUI

struct TidBitListScreen: View {
    @State var showSettings: Bool = false
    var body: some View {

        
        NavigationView{
            
            List{
                //looping through each city in my cityData file
                ForEach(TidBitData){ tidbit in //city is the new name for each value in my list
                    //CLASS EXERCISE pt 2 - attempt styling the layout for each city from the class slides
                    NavigationLink(destination: TidBitScreen(tidbit: tidbit)) { //pass the city as a param to the screen
                        HStack{
                            Image(systemName: tidbit.icon)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .padding(10)
                                .foregroundColor(.white)
                                .background(.blue)
                                .cornerRadius(10)

                            VStack(alignment: .leading){
                                Text(tidbit.name)
                                    .font(.title2)
                                Text(tidbit.category)
                            }

                            Spacer()

                            Text("\(tidbit.no)º")
                                .font(.title)
                                .bold()

                        }//END OF HSTACK (individual)
                    }//END Navigation link
                    
                }//END of loop
            }//END of LIST
            .listStyle(.inset) //changes the styling of list
            .navigationTitle("All of them") //inside navigationView
            .navigationBarTitleDisplayMode(.large)
            //add settings navigation, leading means left corner and trailing means right corner
            .navigationBarItems(trailing: Button(action: {
                //self.showSettings = true other option
                showSettings.toggle()
                //when defining a variable outside of body it is set in stone and cant be changed thats why @state is there
            }){
                Image(systemName: "gearshape")
                    .foregroundColor(.black)
            })
        }//END of navigation
        .sheet(isPresented: $showSettings){//$ = means be ready to change state
            //Text("Settings")
            SettingsScreen()
        }
        
        //TODO: Add navbar button
        //TODO: Tabbar
        //TODO: Onboarding Screen
    }
}

struct CityListScreen_Previews: PreviewProvider {
    static var previews: some View {
        TidBitListScreen()
    }
}
