//
//  AlmanacApp.swift
//  Almanac
//
//  Created by student on 2023/10/18.
//

import SwiftUI

@main
struct AlmanacApp: App {
    @AppStorage("isOnboarded") var isOnboarded: Bool = false
    var body: some Scene {
        WindowGroup {
            if(isOnboarded){
                SplashScreenView()
                    
                        
                        }else{
                OnboardingScreen()
            }
            
//            ContentView()
            //set the screen you want to lauch in app
//            WeatherScreen()
        
        }
    }
}
