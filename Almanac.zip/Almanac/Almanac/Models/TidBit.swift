//
//  TidBit.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import Foundation
struct TidBit: Identifiable {
    var id = UUID() //unique id for each tidbit, that gets auto generated
    var name: String
    var category: String
    var no: Int
    var icon: String
    var info: String
    
}

//dummy city from my blueprint(all my previews)
let dummyTidBit: TidBit = TidBit(
    name: "Campin Tip #1",
    category: "Camping",
    no: 24,
    icon: "cloud.sun",
    info: "When setting up the campsite make sure that the area is as flat as possible!"
)
