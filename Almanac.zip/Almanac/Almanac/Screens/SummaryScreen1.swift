//
//  SummaryScreen.swift
//  Almanac
//
//  Created by student on 2023/10/21.
//

import SwiftUI

struct SummaryScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SummaryScreen_Previews: PreviewProvider {
    static var previews: some View {
        SummaryScreen()
    }
}
