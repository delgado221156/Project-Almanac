//
//  SettingsScreen.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import SwiftUI
/*struct SettingsScreen: View {
    var body: some View {
        ZStack{
            
            LinearGradient(colors: [.purple, .black], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea(.all)
            
            VStack{
                Text("Settings")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .navigationBarItems(leading)
                Text("Almanac is a digital knowledge book about a variety of life topics so that you can be sure whatever life throws at you. you have a comapanion with you ready to help.")
                    .bold()
                    .foregroundColor(.white)
            }
            Spacer()
            }
        }
       
}

struct SettingsScreen_Previews: PreviewProvider {
    static var previews: some View {
        SettingsScreen()
        //add styling
    }
}*/

 struct SettingsScreen: View {
     @Environment(\.dismiss) var dismiss
     @Environment(\.colorScheme) var colorScheme //access the device settings
     @State var username = ""
     @AppStorage("displayMode") var displayMode = "primary"
     var body: some View {
         VStack(spacing:20){
             HStack{
                 Text("Settings")
                     .font(.title)
                 Spacer()
                 
                 Image(systemName: "xmark.circle.fill")
                     .font(.title2)
                     .onTapGesture {
                         dismiss()
                     }
             }
             
             //about us
             GroupBox{
                 HStack{
                     Text("Almanac App")
                    
                     Spacer()
                     //create a link
//                     Link("iOS Developer", destination: URL(string: "https://github.com/delgado221156/Project-Almanac.git")!)
                         .bold()
                     Image(systemName: "link")
                         
                 }
                 Divider()
                 HStack{
                     Text("Version")
                     Spacer()
                     Text("1.10.30")
                         .bold()
                 }
                 Divider()
                 HStack{
                     Text("Developed by")
                     Spacer()
                     Text("Antonio Delgado")
                         .bold()
                 }
             }
             Divider().padding()
             GroupBox{
                 DisclosureGroup("About this app"){
                     Text("This is an app built to be your life companion. Almanac is a knowledge bank of different tidbit designed to help you in your everyday life covering a wide array of subjects.").padding().bold(false)
                 }.foregroundColor(colorScheme == .light ? .black : .white).bold()//? refers to if statement and : means else statement
             }
             GroupBox{
                 DisclosureGroup("About the Developer"){
                     Text("Hi my name is Antonio! I am a second year Product Designer from South Africa, and I love creating awesome tools for people to use!").padding().bold(false)
                 }.foregroundColor(colorScheme == .light ? .black : .white).bold()//? refers to if statement and : means else statement
             }
             if(colorScheme == .light){
                 Text("Colour scheme is set to \(colorScheme == .dark ? "Dark":"Light")")
             }
            Text("Your Username")
                 .foregroundColor(.black) 
             TextField("Your Username", text: $username)
                 .padding()
                 .background(.purple)
                 .cornerRadius(20)
                 .foregroundColor(.black)
                 .bold()
             
             Text("Display Mode")
             Picker("Mode", selection: $displayMode){
                 Text("Primary").tag("primary")
                 Text("Secondary").tag("secondary")
             }
             //.pickerStyle(.wheel)
             .pickerStyle(.segmented)
             
//             Spacer()
         }
         .padding()
     }
 }

 struct SettingsScreen_Previews: PreviewProvider {
     static var previews: some View {
         SettingsScreen()
         //add styling
     }
 }

