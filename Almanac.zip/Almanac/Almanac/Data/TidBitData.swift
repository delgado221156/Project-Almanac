//
//  TidBitData.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import Foundation

let TidBitData: [TidBit] = [
    TidBit(name: "When Setting up a Ground Tent.",category: "CAMPING", no: 1, icon: "tent", info: "When setting up a tent in the outdoors remember to lay down a ground sheet to protect the tent outer from the elements to increase longevity and to avoid mud from getting into the tent."),
    TidBit(name: "Great Resource for Information on Reptiles.",category: "CAMPING", no: 2, icon: "lizard", info: "Use the ASI app from the appstore to search information on South African reptiles, this is a great free resource that does not require an internet connection to view crucial and interesting info on these creatures when out in the wilderness."),
    TidBit(name: "Investing Method",category: "MONEY", no: 3, icon: "dollarsign", info: "One of the best ways to invest money is to put it into an index fund like the S&P500 as it grows year over year and will help you beat inflation. These types of stocks allow people to increase their wealth over time, nut this method only works if you invest into these stocks for an extended period of time otherwise you will lose more money and it will not be a worth while investment, jumping from fund to fund, buy and hold is the key."),
    TidBit(name: "Fancy Boerie Roll Recipe",category: "COOKING", no: 4, icon: "fork.knife", info: "Make wors and buns like usual then add rocket or basil to the boerie to add some much needed flavour."),
    TidBit(name: "Computer forced Reboot",category: "TECH", no: 5, icon: "gear", info: "To force a restart on your computer remember that most PC's will force a restart if the power button is held in for at least 7 seconds.")
]
//var id = UUID() //unique id for each tidbit, that gets auto generated
//var name: String
//var category: String
//var no: Int
//var icon: String
//var info: String
