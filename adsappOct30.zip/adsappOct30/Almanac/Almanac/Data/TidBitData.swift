//
//  TidBitData.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import Foundation

let TidBitData: [TidBit] = [
    TidBit(name: "tidbit1",category: "camp", no: 1, icon: "cloud.sun", info: "wjwe wjhdch djwdvjsdv dkjbsb"),
    TidBit(name: "tidbit2",category: "dance", no: 2, icon: "cloud.rain", info: "wjwe wjhdch djwdvjsdv dkjbsb"),
    TidBit(name: "tidbit3",category: "cooking", no: 3, icon: "cloud", info: "wjwe wjhdch djwdvjsdv dkjbsb"),
    TidBit(name: "tidbit4",category: "money", no: 4, icon: "cloud.sun", info: "wjwe wjhdch djwdvjsdv dkjbsb")
]
//var id = UUID() //unique id for each tidbit, that gets auto generated
//var name: String
//var category: String
//var no: Int
//var icon: String
//var info: String
