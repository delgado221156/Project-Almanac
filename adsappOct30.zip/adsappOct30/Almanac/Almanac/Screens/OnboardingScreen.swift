//
//  OnboardingScreen.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import SwiftUI

struct OnboardingScreen: View {
    @AppStorage("isOnboarded") var isOnboarded = false
    var body: some View {
        VStack{
            TabView{
                
                OnboardingCardView(title: "Welcome!", description: "Almanac, the home of knowledge.", icon: "book")
                    .padding()
                OnboardingCardView(title: "Search", description: "Search info by Category", icon: "magnifyingglass")
     
                    .padding()
                OnboardingCardView(title: "Explore", description: "The world awaits, stay hungry", icon: "backpack")
                    .padding()
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            Button(action:{
                //update app storage
            }){
                HStack{
                    Text("Continue to app")
                        .padding()
                    Spacer()
                    Image(systemName: "arrow.right.circle.fill")
                        .padding()
                }
            }
//            .buttonStyle(.borderedProminent)
            .padding()
            .foregroundColor(.purple)
            
        }
    }
}

struct OnboardingScreen_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingScreen()
    }
}
