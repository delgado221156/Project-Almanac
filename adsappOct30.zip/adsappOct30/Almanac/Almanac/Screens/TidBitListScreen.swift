//
//  TidBitListScreen.swift
//  Almanac
//
//  Created by student on 2023/10/20.
//

import SwiftUI

struct TidBitListScreen: View {
    @State var showSettings: Bool = false
    @State var searchText = ""

    var searchResult: [TidBit] {
        //if search text is none show all
        if(searchText.isEmpty){
            return TidBitData
        }else{
            //return search
            return TidBitData.filter{$0.name.contains(searchText)}
            //if the name contains the search result then return it
            //possibly add an or to check for categories too?????
        }
    }
    
    var body: some View {

        
        NavigationView{
            
            List{
                
                ForEach(searchResult){ tidbit in
                    NavigationLink(destination: TidBitScreen(tidbit: tidbit)) {
                        HStack{
                            Image(systemName: tidbit.icon)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .padding(10)
                                .foregroundColor(.white)
                                .background(.blue)
                                .cornerRadius(10)

                            VStack(alignment: .leading){
                                Text(tidbit.name)
                                    .font(.title2)
                                Text(tidbit.category)
                            }

                            Spacer()

                            Text("\(tidbit.no)º")
                                .font(.title)
                                .bold()

                        }//END OF HSTACK (individual)
                    }//END Navigation link
                    
                }//END of loop
            }//END of LIST
            .listStyle(.inset) //changes the styling of list
            .navigationTitle("All of them") //inside navigationView
            .navigationBarTitleDisplayMode(.large)
            //add settings navigation, leading means left corner and trailing means right corner
            .navigationBarItems(trailing: Button(action: {
                //self.showSettings = true other option
                showSettings.toggle()
                //when defining a variable outside of body it is set in stone and cant be changed thats why @state is there
            }){
                Image(systemName: "gearshape")
                    .foregroundColor(.black)
            })
        }//END of navigation
        .searchable(text: $searchText)//END of navigation
        .sheet(isPresented: $showSettings){//$ = means be ready to change state
            //Text("Settings")
            SettingsScreen()
        
        }

    }
}

struct CityListScreen_Previews: PreviewProvider {
    static var previews: some View {
        TidBitListScreen()
    }
}
